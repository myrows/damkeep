package com.salesianostriana.dam.damkeep

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class DamKeepApplication

fun main(args: Array<String>) {
	runApplication<DamKeepApplication>(*args)
}
